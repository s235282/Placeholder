#ifndef LAB2_WORKER_THREAD_H
#define LAB2_WORKER_THREAD_H

void *thread_func(void *arg);

#endif // LAB2_WORKER_THREAD_H