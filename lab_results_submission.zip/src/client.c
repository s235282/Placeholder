// Minimal TCP echo client for loopback testing
// Usage: ./client
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char **argv) {
    const char *host = "127.0.0.1";
    int port = 9023, iters = 30;

    for (int i = 1; i < argc; i++) 
    {
        if (!strcmp(argv[i], "--host") && i + 1 < argc) 
        {
            host = argv[++i];
        }
        else if (!strcmp(argv[i], "--port") && i + 1 < argc) 
        {
            port = atoi(argv[++i]);
        }
        else if (!strcmp(argv[i], "--iters") && i + 1 < argc) 
        {
            iters = atoi(argv[++i]);
        }
    }

    for (int k = 0; k < iters; k++) 
    {
        
        /* [C1]
         * Explain following in here.
         *
         */
        int fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) 
        {
            perror("socket");
            return 1;
        }

        /* [C2]
         * Explain following in here.
         *
         */
        struct sockaddr_in addr = {0};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        if (inet_pton(AF_INET, host, &addr.sin_addr) != 1) 
        {
            perror("inet_pton");
            return 1;
        }

        /* [C3]
         * Explain following in here.
         *
         */
        if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) 
        {
            perror("connect");
            close(fd);
            return 1;
        }
        printf("Client %d connected\n", k);

        /* [C4]
         * Explain following in here.
         *
         */

        const char *msg = "hello";
        if (send(fd, msg, strlen(msg), 0) < 0) 
        {
            perror("send");
            close(fd);
            return 1;
        }

        char buf[64] = {0};
        if (recv(fd, buf, sizeof(buf), 0) < 0) 
        {
            perror("recv");
            close(fd);
            return 1;
        }
        printf("Client %d received: %s\n", k, buf);

        /* [C5]
         * Explain following in here.
         *
         */
        close(fd);
        printf("Client %d disconnected\n", k);
    }
    return 0;
}
