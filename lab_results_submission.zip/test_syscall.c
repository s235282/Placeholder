#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/syscall.h>
#include <errno.h>

#define __NR_s2_encrypt 468

long s2_encrypt(const char *str, int key) {
    return syscall(__NR_s2_encrypt, str, key);
}

int main(int argc, char *argv[]) {
    int opt;
    char *input_string = NULL;
    int key = -1;
    long result;

    while ((opt = getopt(argc, argv, "s:k:")) != -1) {
        switch (opt) {
            case 's':
                input_string = optarg;
                break;
            case 'k':
                key = atoi(optarg);
                break;
            default:
                fprintf(stderr, "Usage: %s -s <string> -k <key (1-4)>\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }

    if (input_string == NULL || key == -1) {
        fprintf(stderr, "Error: Both -s (string) and -k (key) are required.\n");
        fprintf(stderr, "Usage: %s -s <string> -k <key (1-4)>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    printf("--- Testing sys_s2_encrypt (SC #468) ---\n");
    printf("Input String: \"%s\"\n", input_string);
    printf("Encryption Key: %d\n", key);

    result = s2_encrypt(input_string, key);

    printf("System call returned: %ld\n", result);

    if (result < 0) {
        printf("Error code detail: %s\n", strerror((int)-result));
        return EXIT_FAILURE;
    }

    printf("Success: Kernel function returned 0.\n");
    return EXIT_SUCCESS;
}
