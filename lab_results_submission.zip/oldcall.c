SYSCALL_DEFINE2(s2_encrypt, const char __user *, str, int, key)
{
	char encrypted[256];
	int i = 0;
	
	while (str[i] != '\0' && i < 255) {
		encrypted[i] = str[i] + key;
		i++;
	}
	encrypted[i] = '\0';
	
	printk("s2_encrypt: %s\n", encrypted);
	
	return 0;
}
